from typing import List
from fastapi import APIRouter, Depends, UploadFile, File, Form, Query, Request

from sqlalchemy.orm import Session
from app.core.DB.database import get_db
from app.services.inferdata_service import (
    save_input_before_infer_service,
    save_output_after_infer_service,
    save_binary_output_after_infer_service,
)
from app.schemas.base_schema import BaseResponse
from app.schemas.inferoutput_schema import SaveInferenceResultRequest


inferdata_router = APIRouter(prefix="/infer", tags=["InferData"])


@inferdata_router.post("/save/before", response_model=BaseResponse)
def save_input_before_infer(
    clientId: str = Form(..., description="추론 전 입력 데이터 저장"),
    modelName: str = Form(..., description="추론할 모델 id"),
    dataFiles: List[UploadFile] = File(..., description="추론 입력 데이터 리스트 (.npy, .ply 등)"),
    db: Session = Depends(get_db),
):
    """추론 전 입력 데이터 저장"""
    return save_input_before_infer_service(clientId, modelName, dataFiles, db)


@inferdata_router.post("/save/after", response_model=BaseResponse)
def save_output_after_infer(request: SaveInferenceResultRequest, db: Session = Depends(get_db)):
    """추론 텍스트 결과 저장"""
    return save_output_after_infer_service(request.uid, request.is_ok, request.result, db)


@inferdata_router.post("/save-binay/after", response_model=BaseResponse)
async def save_binay_output_after_infer(
    request: Request,
    uid: str = Query(...),
    is_ok: bool = Query(...),
    extension: str = Query(...),
    db: Session = Depends(get_db),
):
    """추론 바이너리 결과 저장"""
    binary_data = await request.body()

    return save_binary_output_after_infer_service(uid, is_ok, extension, binary_data, db)
