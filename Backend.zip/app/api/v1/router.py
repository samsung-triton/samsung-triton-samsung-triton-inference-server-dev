from fastapi import APIRouter
from app.api.v1.user_router import user_router
from app.api.v1.masterkey_router import mastekey_router
from app.api.v1.inferdata_router import inferdata_router
from app.api.v1.server_router import server_router
from app.api.v1.metrics_router import metrics_router
from app.api.v1.model_config_router import model_config_router
from app.api.v1.models_router import model_router
from app.api.v1.standard_time_router import standard_time_router
from app.api.v1.log_router import log_router
from app.api.v1.notification_router import notification_router

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(user_router)
api_router.include_router(mastekey_router)
api_router.include_router(server_router)
api_router.include_router(metrics_router)
api_router.include_router(standard_time_router)
api_router.include_router(notification_router)
api_router.include_router(model_router)
api_router.include_router(model_config_router)
api_router.include_router(log_router)
api_router.include_router(inferdata_router)
